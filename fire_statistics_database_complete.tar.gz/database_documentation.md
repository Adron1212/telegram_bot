# 📊 ДОКУМЕНТАЦИЯ: База данных для учета и анализа статистики пожаров

## 📋 Содержание
1. [Обзор системы](#обзор-системы)
2. [Структура базы данных](#структура-базы-данных)
3. [Установка и настройка](#установка-и-настройка)
4. [Примеры использования](#примеры-использования)
5. [Аналитические запросы](#аналитические-запросы)
6. [Отчеты и статистика](#отчеты-и-статистика)
7. [Интеграция с приложениями](#интеграция-с-приложениями)

---

## 🎯 Обзор системы

### Назначение
База данных предназначена для комплексного учета и анализа пожаров в регионе, включая:
- ✅ Регистрацию всех случаев пожаров с подробными характеристиками
- ✅ Учет времени реагирования пожарных служб
- ✅ Статистику пострадавших и жертв
- ✅ Анализ задействованных сил и средств
- ✅ Оценку материального ущерба
- ✅ Формирование отчетности и прогнозирование

### Ключевые возможности
- 🔥 **Полный жизненный цикл инцидента**: от вызова до завершения тушения
- ⏱️ **Анализ времени реагирования**: контроль соблюдения нормативов
- 💰 **Учет ущерба**: экономическая оценка последствий
- 👥 **Статистика жертв**: детальный учет пострадавших
- 🚒 **Управление ресурсами**: мониторинг эффективности подразделений
- 📊 **Аналитика**: готовые запросы и представления для отчетности

---

## 🗂️ Структура базы данных

### Схема взаимосвязей

```
regions (регионы)
    ↓
settlements (населенные пункты)
    ↓
fires (пожары) ← главная таблица
    ├→ response_times (время реагирования)
    ├→ casualties (пострадавшие)
    ├→ deployed_resources (силы и средства)
    └→ fire_attachments (документы)
```

### Основные таблицы

#### 1. **fires** - Главная таблица пожаров
Содержит основную информацию о каждом пожаре:
- **Дата и место**: дата, время, адрес, координаты
- **Характеристики**: тип объекта, класс пожара, степень серьезности
- **Причина**: причина возникновения и детали
- **Площадь**: площадь повреждения и распространения огня
- **Ущерб**: оценочный и фактический ущерб в рублях
- **Погода**: температура, ветер, влажность
- **Статус**: активный, локализован, потушен

#### 2. **response_times** - Время реагирования
Фиксирует все временные метки процесса тушения:
- Время получения вызова
- Время высылки подразделения
- Время прибытия на место
- Время подачи воды
- Время локализации
- Время полного тушения

**Автоматически рассчитывается:**
- Задержка высылки
- Время в пути
- Общее время реагирования
- Длительность локализации
- Общая продолжительность работ

#### 3. **casualties** - Пострадавшие и жертвы
Детальная статистика:
- Погибшие (всего, на месте, в больнице, дети)
- Пострадавшие (всего, тяжелые, средние, легкие, дети)
- Эвакуированные (всего, дети)
- Пострадавшие среди спасателей

#### 4. **deployed_resources** - Силы и средства
Учет задействованных ресурсов:
- Личный состав (количество, офицеры)
- Техника (тип, количество)
- Оборудование (рукава, автолестницы)
- Расход ресурсов (вода, пена)
- Время работы подразделения

### Справочные таблицы

- **regions** - регионы
- **settlements** - населенные пункты
- **object_types** - типы объектов (жилые, промышленные, транспорт и т.д.)
- **fire_causes** - причины пожаров (технические, природные, человеческий фактор)
- **fire_departments** - пожарные подразделения
- **vehicle_types** - типы пожарной техники

### Аналитические представления (VIEW)

#### v_fires_detailed
Детальная информация о пожарах со всеми связанными данными в одном запросе.

#### v_region_statistics
Сводная статистика по регионам за текущий год.

#### v_cause_statistics
Статистика по причинам пожаров с процентным соотношением.

#### v_department_performance
Показатели эффективности пожарных подразделений.

---

## 🔧 Установка и настройка

### Требования
- MySQL 8.0+ или PostgreSQL 12+
- Минимум 500 МБ свободного места
- Права администратора для создания базы данных

### Установка

#### Вариант 1: MySQL/MariaDB

```bash
# Вход в MySQL
mysql -u root -p

# Выполнение скрипта
source /path/to/fire_statistics_database.sql
```

#### Вариант 2: PostgreSQL (с адаптацией)

```bash
# Вход в PostgreSQL
psql -U postgres

# Создание базы данных
CREATE DATABASE fire_statistics_db;

# Подключение к базе
\c fire_statistics_db

# Выполнение адаптированного скрипта
\i /path/to/fire_statistics_database_pg.sql
```

### Первоначальная настройка

```sql
-- 1. Добавьте ваши регионы
INSERT INTO regions (region_name, region_code, population, area_km2) 
VALUES ('Ваш регион', 'КОД', население, площадь);

-- 2. Добавьте населенные пункты
INSERT INTO settlements (region_id, settlement_name, settlement_type, population) 
VALUES (1, 'Город', 'город', население);

-- 3. Добавьте пожарные подразделения
INSERT INTO fire_departments (region_id, department_name, address, phone) 
VALUES (1, 'ПСЧ-1', 'Адрес', '+7-XXX-XXX-XX-XX');

-- 4. Настройте справочники типов объектов и причин
-- (уже предзаполнены базовыми значениями)
```

---

## 💡 Примеры использования

### Регистрация нового пожара

```sql
-- Шаг 1: Создаем запись о пожаре
INSERT INTO fires (
    incident_date, incident_time, detection_datetime,
    settlement_id, address, object_type_id, cause_id,
    severity_level, area_fire_m2, estimated_damage_rub,
    status
) VALUES (
    '2026-02-10', '14:30:00', '2026-02-10 14:30:00',
    1, 'ул. Ленина, д. 25, кв. 10',
    1, -- Жилой дом
    2, -- Неосторожное обращение с огнем
    'средний', 45.5, 1500000,
    'активный'
);

-- Получаем ID созданного пожара
SET @fire_id = LAST_INSERT_ID();

-- Шаг 2: Фиксируем время реагирования
INSERT INTO response_times (
    fire_id, call_received_time, dispatch_time, arrival_time,
    primary_department_id
) VALUES (
    @fire_id,
    '2026-02-10 14:30:00',
    '2026-02-10 14:32:00',
    '2026-02-10 14:41:00',
    1
);

-- Шаг 3: Добавляем информацию о пострадавших (если есть)
INSERT INTO casualties (
    fire_id, deaths_total, injured_total, evacuated_total
) VALUES (
    @fire_id, 0, 2, 15
);

-- Шаг 4: Регистрируем задействованные силы
INSERT INTO deployed_resources (
    fire_id, department_id, personnel_count, vehicle_type_id, vehicle_count,
    arrival_time, water_used_liters
) VALUES (
    @fire_id, 1, 12, 1, 2,
    '2026-02-10 14:41:00', 8000
);
```

### Обновление статуса пожара

```sql
-- Пожар локализован
UPDATE fires 
SET status = 'локализован' 
WHERE fire_id = @fire_id;

-- Пожар потушен
UPDATE fires 
SET status = 'потушен' 
WHERE fire_id = @fire_id;

-- Обновление времени локализации и тушения
UPDATE response_times 
SET 
    localization_time = '2026-02-10 15:15:00',
    extinguish_time = '2026-02-10 16:30:00'
WHERE fire_id = @fire_id;

-- Обновление фактического ущерба после оценки
UPDATE fires 
SET actual_damage_rub = 1850000 
WHERE fire_id = @fire_id;
```

---

## 📊 Аналитические запросы

### 1. Статистика за период

```sql
-- Общая статистика за последний месяц
SELECT 
    COUNT(*) AS всего_пожаров,
    SUM(CASE WHEN severity_level IN ('крупный', 'особо крупный') THEN 1 ELSE 0 END) AS крупных_пожаров,
    SUM(area_fire_m2) AS общая_площадь_м2,
    SUM(COALESCE(actual_damage_rub, estimated_damage_rub, 0)) AS общий_ущерб_руб,
    SUM((SELECT COALESCE(deaths_total, 0) FROM casualties WHERE casualties.fire_id = fires.fire_id)) AS погибших,
    SUM((SELECT COALESCE(injured_total, 0) FROM casualties WHERE casualties.fire_id = fires.fire_id)) AS пострадавших
FROM fires
WHERE incident_date >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH);
```

### 2. ТОП-5 причин пожаров

```sql
SELECT 
    fc.cause_name AS причина,
    COUNT(*) AS количество,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM fires), 2) AS процент
FROM fires f
JOIN fire_causes fc ON f.cause_id = fc.cause_id
WHERE YEAR(f.incident_date) = YEAR(CURDATE())
GROUP BY fc.cause_name
ORDER BY количество DESC
LIMIT 5;
```

### 3. Анализ времени реагирования

```sql
-- Среднее время реагирования по подразделениям
SELECT 
    fd.department_name AS подразделение,
    COUNT(*) AS выездов,
    AVG(rt.response_time_min) AS среднее_время_мин,
    MIN(rt.response_time_min) AS минимальное_мин,
    MAX(rt.response_time_min) AS максимальное_мин,
    SUM(CASE WHEN rt.response_time_min <= 10 THEN 1 ELSE 0 END) AS в_норме,
    ROUND(SUM(CASE WHEN rt.response_time_min <= 10 THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) AS процент_в_норме
FROM response_times rt
JOIN fire_departments fd ON rt.primary_department_id = fd.department_id
WHERE rt.call_received_time >= DATE_SUB(NOW(), INTERVAL 3 MONTH)
GROUP BY fd.department_name
ORDER BY среднее_время_мин;
```

### 4. Динамика по месяцам

```sql
-- Вызов хранимой процедуры
CALL sp_monthly_fire_dynamics(2026);
```

### 5. Карта рисков (самые опасные места)

```sql
SELECT 
    s.settlement_name AS населенный_пункт,
    COUNT(f.fire_id) AS количество_пожаров,
    SUM(COALESCE(c.deaths_total, 0)) AS погибших,
    SUM(COALESCE(c.injured_total, 0)) AS пострадавших,
    SUM(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)) AS ущерб_руб
FROM fires f
JOIN settlements s ON f.settlement_id = s.settlement_id
LEFT JOIN casualties c ON f.fire_id = c.fire_id
WHERE f.incident_date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
GROUP BY s.settlement_name
HAVING количество_пожаров >= 3
ORDER BY погибших DESC, ущерб_руб DESC;
```

### 6. Эффективность подразделений

```sql
SELECT * FROM v_department_performance
ORDER BY avg_response_time_min;
```

### 7. Анализ по типам объектов

```sql
SELECT 
    ot.type_name AS тип_объекта,
    ot.type_category AS категория,
    COUNT(f.fire_id) AS пожаров,
    AVG(f.area_fire_m2) AS средняя_площадь_м2,
    AVG(COALESCE(f.actual_damage_rub, f.estimated_damage_rub)) AS средний_ущерб_руб,
    SUM(COALESCE(c.deaths_total, 0)) AS погибших
FROM object_types ot
LEFT JOIN fires f ON ot.object_type_id = f.object_type_id
LEFT JOIN casualties c ON f.fire_id = c.fire_id
WHERE f.incident_date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
GROUP BY ot.type_name, ot.type_category
ORDER BY пожаров DESC;
```

---

## 📈 Отчеты и статистика

### Ежемесячный отчет

```sql
-- Комплексный отчет за месяц
SELECT 
    'Всего пожаров' AS показатель,
    COUNT(*) AS значение
FROM fires
WHERE YEAR(incident_date) = YEAR(CURDATE()) 
  AND MONTH(incident_date) = MONTH(CURDATE())

UNION ALL

SELECT 'Крупных пожаров', 
       COUNT(*) 
FROM fires
WHERE severity_level IN ('крупный', 'особо крупный')
  AND YEAR(incident_date) = YEAR(CURDATE()) 
  AND MONTH(incident_date) = MONTH(CURDATE())

UNION ALL

SELECT 'Погибших всего', 
       COALESCE(SUM(deaths_total), 0)
FROM casualties c
JOIN fires f ON c.fire_id = f.fire_id
WHERE YEAR(f.incident_date) = YEAR(CURDATE()) 
  AND MONTH(f.incident_date) = MONTH(CURDATE())

UNION ALL

SELECT 'Пострадавших всего', 
       COALESCE(SUM(injured_total), 0)
FROM casualties c
JOIN fires f ON c.fire_id = f.fire_id
WHERE YEAR(f.incident_date) = YEAR(CURDATE()) 
  AND MONTH(f.incident_date) = MONTH(CURDATE())

UNION ALL

SELECT 'Ущерб (млн руб)', 
       ROUND(SUM(COALESCE(actual_damage_rub, estimated_damage_rub, 0)) / 1000000, 2)
FROM fires
WHERE YEAR(incident_date) = YEAR(CURDATE()) 
  AND MONTH(incident_date) = MONTH(CURDATE());
```

### Годовой сравнительный отчет

```sql
-- Сравнение с предыдущим годом
SELECT 
    YEAR(incident_date) AS год,
    COUNT(*) AS пожаров,
    SUM(CASE WHEN severity_level IN ('крупный', 'особо крупный') THEN 1 ELSE 0 END) AS крупных,
    SUM(COALESCE((SELECT deaths_total FROM casualties WHERE casualties.fire_id = fires.fire_id), 0)) AS погибших,
    SUM(COALESCE((SELECT injured_total FROM casualties WHERE casualties.fire_id = fires.fire_id), 0)) AS пострадавших,
    ROUND(SUM(COALESCE(actual_damage_rub, estimated_damage_rub, 0)) / 1000000, 2) AS ущерб_млн_руб
FROM fires
WHERE YEAR(incident_date) IN (YEAR(CURDATE()), YEAR(CURDATE()) - 1)
GROUP BY YEAR(incident_date)
ORDER BY год DESC;
```

### Отчет по использованию ресурсов

```sql
SELECT 
    fd.department_name AS подразделение,
    SUM(dr.personnel_count) AS всего_личного_состава,
    SUM(dr.vehicle_count) AS всего_техники,
    SUM(dr.water_used_liters) AS израсходовано_воды_л,
    SUM(dr.foam_used_liters) AS израсходовано_пены_л,
    COUNT(DISTINCT dr.fire_id) AS пожаров_обслужено
FROM deployed_resources dr
JOIN fire_departments fd ON dr.department_id = fd.department_id
JOIN fires f ON dr.fire_id = f.fire_id
WHERE f.incident_date >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH)
GROUP BY fd.department_name
ORDER BY пожаров_обслужено DESC;
```

---

## 🔗 Интеграция с приложениями

### Подключение через Python

```python
import mysql.connector
from datetime import datetime

# Подключение к базе данных
connection = mysql.connector.connect(
    host='localhost',
    user='fire_user',
    password='secure_password',
    database='fire_statistics_db'
)

cursor = connection.cursor()

# Пример: Регистрация нового пожара
def register_fire(incident_date, incident_time, address, settlement_id, 
                  object_type_id, cause_id):
    query = """
    INSERT INTO fires 
    (incident_date, incident_time, detection_datetime, settlement_id, 
     address, object_type_id, cause_id, status)
    VALUES (%s, %s, %s, %s, %s, %s, %s, 'активный')
    """
    
    detection_datetime = datetime.combine(incident_date, incident_time)
    
    cursor.execute(query, (incident_date, incident_time, detection_datetime,
                          settlement_id, address, object_type_id, cause_id))
    connection.commit()
    
    return cursor.lastrowid

# Пример: Получение статистики
def get_monthly_statistics(year, month):
    query = """
    SELECT 
        COUNT(*) as total_fires,
        SUM(COALESCE(actual_damage_rub, estimated_damage_rub, 0)) as total_damage
    FROM fires
    WHERE YEAR(incident_date) = %s AND MONTH(incident_date) = %s
    """
    
    cursor.execute(query, (year, month))
    return cursor.fetchone()

# Использование
fire_id = register_fire(
    datetime.now().date(),
    datetime.now().time(),
    'ул. Примерная, д. 1',
    1, 1, 2
)

stats = get_monthly_statistics(2026, 2)
print(f"Пожаров в феврале: {stats[0]}, Ущерб: {stats[1]} руб.")
```

### REST API пример (Node.js + Express)

```javascript
const express = require('express');
const mysql = require('mysql2/promise');

const app = express();
app.use(express.json());

// Пул подключений
const pool = mysql.createPool({
    host: 'localhost',
    user: 'fire_user',
    password: 'secure_password',
    database: 'fire_statistics_db'
});

// Получить все пожары за период
app.get('/api/fires', async (req, res) => {
    const { date_from, date_to } = req.query;
    
    const [rows] = await pool.query(
        'SELECT * FROM v_fires_detailed WHERE incident_date BETWEEN ? AND ?',
        [date_from, date_to]
    );
    
    res.json(rows);
});

// Зарегистрировать новый пожар
app.post('/api/fires', async (req, res) => {
    const { incident_date, incident_time, address, settlement_id,
            object_type_id, cause_id } = req.body;
    
    const [result] = await pool.query(
        `INSERT INTO fires 
         (incident_date, incident_time, detection_datetime, settlement_id, 
          address, object_type_id, cause_id, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'активный')`,
        [incident_date, incident_time, 
         `${incident_date} ${incident_time}`,
         settlement_id, address, object_type_id, cause_id]
    );
    
    res.json({ fire_id: result.insertId });
});

// Статистика по региону
app.get('/api/statistics/region/:region_id', async (req, res) => {
    const [rows] = await pool.query(
        'SELECT * FROM v_region_statistics WHERE region_id = ?',
        [req.params.region_id]
    );
    
    res.json(rows[0]);
});

app.listen(3000, () => {
    console.log('API сервер запущен на порту 3000');
});
```

---

## 🛠️ Обслуживание и оптимизация

### Резервное копирование

```bash
# Ежедневный бэкап
mysqldump -u root -p fire_statistics_db > backup_$(date +%Y%m%d).sql

# Бэкап с сжатием
mysqldump -u root -p fire_statistics_db | gzip > backup_$(date +%Y%m%d).sql.gz
```

### Очистка старых данных

```sql
-- Архивирование данных старше 5 лет
CREATE TABLE fires_archive LIKE fires;

INSERT INTO fires_archive 
SELECT * FROM fires 
WHERE incident_date < DATE_SUB(CURDATE(), INTERVAL 5 YEAR);

DELETE FROM fires 
WHERE incident_date < DATE_SUB(CURDATE(), INTERVAL 5 YEAR);
```

### Оптимизация производительности

```sql
-- Анализ и оптимизация таблиц
ANALYZE TABLE fires, response_times, casualties, deployed_resources;
OPTIMIZE TABLE fires, response_times, casualties, deployed_resources;

-- Проверка использования индексов
EXPLAIN SELECT * FROM v_fires_detailed 
WHERE incident_date BETWEEN '2026-01-01' AND '2026-12-31';
```

---

## 📞 Поддержка и развитие

### Возможные доработки

1. **Географическая информация**
   - Интеграция с картографическими сервисами
   - Визуализация на карте
   - Расчет зон риска

2. **Прогнозирование**
   - ML-модели для предсказания пожаров
   - Анализ сезонных паттернов
   - Определение факторов риска

3. **Мобильное приложение**
   - Регистрация пожаров в полевых условиях
   - Push-уведомления
   - Offline-режим

4. **Интеграция с внешними системами**
   - Метеослужбы
   - Системы видеонаблюдения
   - Датчики пожарной сигнализации

5. **Расширенная аналитика**
   - Дашборды и визуализация
   - Автоматические отчеты
   - Экспорт в различные форматы

---

## 📝 Лицензия и авторство

Данная база данных разработана для служб МЧС и пожарной охраны.
Свободна для использования в государственных и муниципальных организациях.

**Версия:** 1.0  
**Дата:** Февраль 2026  
**Статус:** Production Ready
