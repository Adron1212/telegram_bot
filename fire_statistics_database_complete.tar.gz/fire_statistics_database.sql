-- ====================================================================
-- БАЗА ДАННЫХ ДЛЯ УЧЕТА И АНАЛИЗА СТАТИСТИКИ ПОЖАРОВ В РЕГИОНЕ
-- ====================================================================
-- Версия: 1.0
-- СУБД: PostgreSQL / MySQL (совместимо)
-- ====================================================================

-- Создание базы данных
CREATE DATABASE IF NOT EXISTS fire_statistics_db
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE fire_statistics_db;

-- ====================================================================
-- СПРАВОЧНЫЕ ТАБЛИЦЫ
-- ====================================================================

-- Таблица регионов
CREATE TABLE regions (
    region_id INT PRIMARY KEY AUTO_INCREMENT,
    region_name VARCHAR(200) NOT NULL,
    region_code VARCHAR(10),
    population INT,
    area_km2 DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Таблица населенных пунктов
CREATE TABLE settlements (
    settlement_id INT PRIMARY KEY AUTO_INCREMENT,
    region_id INT NOT NULL,
    settlement_name VARCHAR(200) NOT NULL,
    settlement_type ENUM('город', 'поселок', 'село', 'деревня') NOT NULL,
    population INT,
    FOREIGN KEY (region_id) REFERENCES regions(region_id)
);

-- Таблица типов объектов
CREATE TABLE object_types (
    object_type_id INT PRIMARY KEY AUTO_INCREMENT,
    type_name VARCHAR(100) NOT NULL,
    type_category ENUM('жилой', 'промышленный', 'коммерческий', 'транспорт', 'лесной', 'сельхоз', 'прочее') NOT NULL,
    description TEXT
);

-- Таблица причин пожаров
CREATE TABLE fire_causes (
    cause_id INT PRIMARY KEY AUTO_INCREMENT,
    cause_name VARCHAR(200) NOT NULL,
    cause_category ENUM('техническая', 'природная', 'человеческий фактор', 'поджог', 'неустановленная') NOT NULL,
    description TEXT
);

-- Таблица пожарных подразделений
CREATE TABLE fire_departments (
    department_id INT PRIMARY KEY AUTO_INCREMENT,
    region_id INT NOT NULL,
    department_name VARCHAR(200) NOT NULL,
    address TEXT,
    phone VARCHAR(50),
    staff_count INT,
    vehicle_count INT,
    FOREIGN KEY (region_id) REFERENCES regions(region_id)
);

-- Таблица типов техники
CREATE TABLE vehicle_types (
    vehicle_type_id INT PRIMARY KEY AUTO_INCREMENT,
    type_name VARCHAR(100) NOT NULL,
    capacity_liters INT,
    crew_size INT,
    description TEXT
);

-- ====================================================================
-- ОСНОВНЫЕ ТАБЛИЦЫ
-- ====================================================================

-- Главная таблица пожаров
CREATE TABLE fires (
    fire_id INT PRIMARY KEY AUTO_INCREMENT,
    
    -- Дата, время и место
    incident_date DATE NOT NULL,
    incident_time TIME NOT NULL,
    detection_datetime DATETIME NOT NULL,
    settlement_id INT NOT NULL,
    address TEXT NOT NULL,
    coordinates_lat DECIMAL(10,8),
    coordinates_lon DECIMAL(11,8),
    
    -- Тип объекта
    object_type_id INT NOT NULL,
    object_name VARCHAR(300),
    
    -- Причина
    cause_id INT,
    cause_details TEXT,
    
    -- Характеристики пожара
    fire_class ENUM('A', 'B', 'C', 'D', 'E', 'F') COMMENT 'Класс пожара по виду горючего материала',
    severity_level ENUM('малый', 'средний', 'крупный', 'особо крупный') NOT NULL,
    
    -- Площадь и ущерб
    area_damaged_m2 DECIMAL(12,2),
    area_fire_m2 DECIMAL(12,2),
    floors_affected INT,
    estimated_damage_rub DECIMAL(15,2),
    actual_damage_rub DECIMAL(15,2),
    insured BOOLEAN DEFAULT FALSE,
    insurance_payout_rub DECIMAL(15,2),
    
    -- Погодные условия
    weather_temp_celsius DECIMAL(5,2),
    weather_wind_speed_ms DECIMAL(5,2),
    weather_humidity_percent INT,
    weather_conditions VARCHAR(100),
    
    -- Статус
    status ENUM('активный', 'локализован', 'потушен', 'под наблюдением') DEFAULT 'активный',
    
    -- Системные поля
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (settlement_id) REFERENCES settlements(settlement_id),
    FOREIGN KEY (object_type_id) REFERENCES object_types(object_type_id),
    FOREIGN KEY (cause_id) REFERENCES fire_causes(cause_id),
    
    INDEX idx_incident_date (incident_date),
    INDEX idx_settlement (settlement_id),
    INDEX idx_status (status),
    INDEX idx_severity (severity_level)
);

-- Таблица времени реагирования
CREATE TABLE response_times (
    response_id INT PRIMARY KEY AUTO_INCREMENT,
    fire_id INT NOT NULL,
    
    -- Временные метки
    call_received_time DATETIME NOT NULL,
    dispatch_time DATETIME NOT NULL,
    arrival_time DATETIME NOT NULL,
    water_supply_time DATETIME,
    localization_time DATETIME,
    extinguish_time DATETIME,
    
    -- Расчетные интервалы (в минутах)
    dispatch_delay_min INT GENERATED ALWAYS AS (TIMESTAMPDIFF(MINUTE, call_received_time, dispatch_time)) STORED,
    travel_time_min INT GENERATED ALWAYS AS (TIMESTAMPDIFF(MINUTE, dispatch_time, arrival_time)) STORED,
    response_time_min INT GENERATED ALWAYS AS (TIMESTAMPDIFF(MINUTE, call_received_time, arrival_time)) STORED,
    localization_duration_min INT GENERATED ALWAYS AS (TIMESTAMPDIFF(MINUTE, arrival_time, localization_time)) STORED,
    total_duration_min INT GENERATED ALWAYS AS (TIMESTAMPDIFF(MINUTE, call_received_time, extinguish_time)) STORED,
    
    -- Ответственное подразделение
    primary_department_id INT NOT NULL,
    
    FOREIGN KEY (fire_id) REFERENCES fires(fire_id) ON DELETE CASCADE,
    FOREIGN KEY (primary_department_id) REFERENCES fire_departments(department_id),
    
    INDEX idx_fire (fire_id),
    INDEX idx_response_time (response_time_min)
);

-- Таблица пострадавших и жертв
CREATE TABLE casualties (
    casualty_id INT PRIMARY KEY AUTO_INCREMENT,
    fire_id INT NOT NULL,
    
    -- Статистика
    deaths_total INT DEFAULT 0,
    deaths_on_site INT DEFAULT 0,
    deaths_in_hospital INT DEFAULT 0,
    deaths_children INT DEFAULT 0,
    
    injured_total INT DEFAULT 0,
    injured_severe INT DEFAULT 0,
    injured_moderate INT DEFAULT 0,
    injured_minor INT DEFAULT 0,
    injured_children INT DEFAULT 0,
    
    evacuated_total INT DEFAULT 0,
    evacuated_children INT DEFAULT 0,
    
    rescuers_injured INT DEFAULT 0,
    rescuers_deaths INT DEFAULT 0,
    
    -- Дополнительная информация
    notes TEXT,
    
    FOREIGN KEY (fire_id) REFERENCES fires(fire_id) ON DELETE CASCADE,
    INDEX idx_fire (fire_id)
);

-- Таблица задействованных сил и средств
CREATE TABLE deployed_resources (
    deployment_id INT PRIMARY KEY AUTO_INCREMENT,
    fire_id INT NOT NULL,
    department_id INT NOT NULL,
    
    -- Личный состав
    personnel_count INT NOT NULL,
    officers_count INT DEFAULT 0,
    
    -- Техника
    vehicle_type_id INT,
    vehicle_count INT DEFAULT 0,
    
    -- Оборудование
    hose_lines_count INT DEFAULT 0,
    aerial_devices_count INT DEFAULT 0,
    
    -- Время работы
    arrival_time DATETIME,
    departure_time DATETIME,
    work_duration_min INT GENERATED ALWAYS AS (TIMESTAMPDIFF(MINUTE, arrival_time, departure_time)) STORED,
    
    -- Расход ресурсов
    water_used_liters INT,
    foam_used_liters INT,
    
    FOREIGN KEY (fire_id) REFERENCES fires(fire_id) ON DELETE CASCADE,
    FOREIGN KEY (department_id) REFERENCES fire_departments(department_id),
    FOREIGN KEY (vehicle_type_id) REFERENCES vehicle_types(vehicle_type_id),
    
    INDEX idx_fire (fire_id),
    INDEX idx_department (department_id)
);

-- Таблица фотографий и документов
CREATE TABLE fire_attachments (
    attachment_id INT PRIMARY KEY AUTO_INCREMENT,
    fire_id INT NOT NULL,
    file_type ENUM('фото', 'видео', 'документ', 'схема', 'отчет') NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_name VARCHAR(200) NOT NULL,
    description TEXT,
    upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (fire_id) REFERENCES fires(fire_id) ON DELETE CASCADE,
    INDEX idx_fire (fire_id)
);

-- ====================================================================
-- ПРЕДСТАВЛЕНИЯ ДЛЯ АНАЛИТИКИ
-- ====================================================================

-- Детальная информация о пожарах
CREATE VIEW v_fires_detailed AS
SELECT 
    f.fire_id,
    f.incident_date,
    f.incident_time,
    r.region_name,
    s.settlement_name,
    s.settlement_type,
    f.address,
    ot.type_name AS object_type,
    ot.type_category,
    fc.cause_name,
    fc.cause_category,
    f.severity_level,
    f.area_damaged_m2,
    f.area_fire_m2,
    f.estimated_damage_rub,
    f.actual_damage_rub,
    COALESCE(c.deaths_total, 0) AS deaths,
    COALESCE(c.injured_total, 0) AS injured,
    COALESCE(c.evacuated_total, 0) AS evacuated,
    rt.response_time_min,
    rt.total_duration_min,
    fd.department_name,
    f.status
FROM fires f
LEFT JOIN settlements s ON f.settlement_id = s.settlement_id
LEFT JOIN regions r ON s.region_id = r.region_id
LEFT JOIN object_types ot ON f.object_type_id = ot.object_type_id
LEFT JOIN fire_causes fc ON f.cause_id = fc.cause_id
LEFT JOIN casualties c ON f.fire_id = c.fire_id
LEFT JOIN response_times rt ON f.fire_id = rt.fire_id
LEFT JOIN fire_departments fd ON rt.primary_department_id = fd.department_id;

-- Статистика по регионам
CREATE VIEW v_region_statistics AS
SELECT 
    r.region_id,
    r.region_name,
    COUNT(f.fire_id) AS total_fires,
    SUM(CASE WHEN f.severity_level = 'крупный' OR f.severity_level = 'особо крупный' THEN 1 ELSE 0 END) AS major_fires,
    SUM(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)) AS total_damage_rub,
    SUM(COALESCE(c.deaths_total, 0)) AS total_deaths,
    SUM(COALESCE(c.injured_total, 0)) AS total_injured,
    AVG(rt.response_time_min) AS avg_response_time_min,
    YEAR(CURRENT_DATE) AS statistics_year
FROM regions r
LEFT JOIN settlements s ON r.region_id = s.region_id
LEFT JOIN fires f ON s.settlement_id = f.settlement_id
LEFT JOIN casualties c ON f.fire_id = c.fire_id
LEFT JOIN response_times rt ON f.fire_id = rt.fire_id
WHERE YEAR(f.incident_date) = YEAR(CURRENT_DATE)
GROUP BY r.region_id, r.region_name;

-- Статистика по причинам
CREATE VIEW v_cause_statistics AS
SELECT 
    fc.cause_id,
    fc.cause_name,
    fc.cause_category,
    COUNT(f.fire_id) AS fire_count,
    ROUND(COUNT(f.fire_id) * 100.0 / (SELECT COUNT(*) FROM fires), 2) AS percentage,
    SUM(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)) AS total_damage_rub,
    SUM(COALESCE(c.deaths_total, 0)) AS total_deaths,
    SUM(COALESCE(c.injured_total, 0)) AS total_injured
FROM fire_causes fc
LEFT JOIN fires f ON fc.cause_id = f.cause_id
LEFT JOIN casualties c ON f.fire_id = c.fire_id
GROUP BY fc.cause_id, fc.cause_name, fc.cause_category
ORDER BY fire_count DESC;

-- Эффективность подразделений
CREATE VIEW v_department_performance AS
SELECT 
    fd.department_id,
    fd.department_name,
    r.region_name,
    COUNT(DISTINCT rt.fire_id) AS fires_attended,
    AVG(rt.response_time_min) AS avg_response_time_min,
    AVG(rt.total_duration_min) AS avg_total_duration_min,
    SUM(dr.personnel_count) AS total_personnel_deployed,
    SUM(dr.vehicle_count) AS total_vehicles_deployed,
    SUM(COALESCE(c.rescuers_injured, 0)) AS rescuers_injured,
    SUM(COALESCE(c.rescuers_deaths, 0)) AS rescuers_deaths
FROM fire_departments fd
LEFT JOIN regions r ON fd.region_id = r.region_id
LEFT JOIN response_times rt ON fd.department_id = rt.primary_department_id
LEFT JOIN deployed_resources dr ON fd.department_id = dr.department_id
LEFT JOIN casualties c ON rt.fire_id = c.fire_id
GROUP BY fd.department_id, fd.department_name, r.region_name;

-- ====================================================================
-- ПРИМЕРЫ ВСТАВКИ ТЕСТОВЫХ ДАННЫХ
-- ====================================================================

-- Регионы
INSERT INTO regions (region_name, region_code, population, area_km2) VALUES
('Московская область', '50', 7500000, 44379),
('Санкт-Петербург', '78', 5400000, 1439),
('Свердловская область', '66', 4300000, 194307);

-- Населенные пункты
INSERT INTO settlements (region_id, settlement_name, settlement_type, population) VALUES
(1, 'Москва', 'город', 13000000),
(1, 'Подольск', 'город', 300000),
(2, 'Санкт-Петербург', 'город', 5400000),
(3, 'Екатеринбург', 'город', 1500000);

-- Типы объектов
INSERT INTO object_types (type_name, type_category, description) VALUES
('Жилой дом', 'жилой', 'Многоквартирный жилой дом'),
('Частный дом', 'жилой', 'Индивидуальный жилой дом'),
('Производственное здание', 'промышленный', 'Промышленное или производственное здание'),
('Склад', 'промышленный', 'Складское помещение'),
('Торговый центр', 'коммерческий', 'Торгово-развлекательный центр'),
('Автомобиль', 'транспорт', 'Легковой или грузовой автомобиль'),
('Лесной массив', 'лесной', 'Лесной или травяной пожар'),
('Офисное здание', 'коммерческий', 'Административное или офисное здание');

-- Причины пожаров
INSERT INTO fire_causes (cause_name, cause_category, description) VALUES
('Нарушение правил эксплуатации электрооборудования', 'техническая', 'Короткое замыкание, перегрузка сети'),
('Неосторожное обращение с огнем', 'человеческий фактор', 'Курение, использование открытого огня'),
('Нарушение правил пожарной безопасности при проведении огневых работ', 'человеческий фактор', 'Сварочные работы без соблюдения ПБ'),
('Поджог', 'поджог', 'Умышленное поджигание'),
('Детская шалость с огнем', 'человеческий фактор', 'Игры детей с огнем'),
('Удар молнии', 'природная', 'Природное возгорание от молнии'),
('Самовозгорание', 'техническая', 'Самовозгорание материалов'),
('Неустановленная', 'неустановленная', 'Причина не установлена');

-- Пожарные подразделения
INSERT INTO fire_departments (region_id, department_name, address, phone, staff_count, vehicle_count) VALUES
(1, 'ПСЧ-1 ГКУ МО "Мособлпожспас"', 'г. Подольск, ул. Пожарная, д. 1', '+7-495-123-45-67', 45, 8),
(2, 'ПСЧ-5 ГУ МЧС России по г. Санкт-Петербургу', 'г. Санкт-Петербург, Невский пр., д. 100', '+7-812-234-56-78', 60, 12),
(3, 'ПСЧ-3 ГУ МЧС России по Свердловской области', 'г. Екатеринбург, ул. Огнеборцев, д. 5', '+7-343-345-67-89', 50, 10);

-- Типы техники
INSERT INTO vehicle_types (type_name, capacity_liters, crew_size, description) VALUES
('АЦ (автоцистерна)', 4000, 6, 'Автоцистерна пожарная'),
('АЛ (автолестница)', 500, 4, 'Автолестница пожарная'),
('АНР (автомобиль насосно-рукавный)', 1000, 4, 'Насосно-рукавный автомобиль'),
('Автомобиль первой помощи', 500, 3, 'Быстрого реагирования');

-- ====================================================================
-- АНАЛИТИЧЕСКИЕ ЗАПРОСЫ
-- ====================================================================

-- Примеры готовых запросов для анализа

-- 1. Динамика пожаров по месяцам текущего года
DELIMITER //
CREATE PROCEDURE sp_monthly_fire_dynamics(IN year_param INT)
BEGIN
    SELECT 
        MONTH(incident_date) AS month_num,
        MONTHNAME(incident_date) AS month_name,
        COUNT(*) AS fire_count,
        SUM(CASE WHEN severity_level IN ('крупный', 'особо крупный') THEN 1 ELSE 0 END) AS major_fires,
        SUM(COALESCE(actual_damage_rub, estimated_damage_rub, 0)) AS total_damage,
        SUM(COALESCE((SELECT deaths_total FROM casualties WHERE casualties.fire_id = fires.fire_id), 0)) AS deaths,
        SUM(COALESCE((SELECT injured_total FROM casualties WHERE casualties.fire_id = fires.fire_id), 0)) AS injured
    FROM fires
    WHERE YEAR(incident_date) = year_param
    GROUP BY MONTH(incident_date), MONTHNAME(incident_date)
    ORDER BY month_num;
END //
DELIMITER ;

-- 2. ТОП-10 самых опасных типов объектов
DELIMITER //
CREATE PROCEDURE sp_most_dangerous_object_types()
BEGIN
    SELECT 
        ot.type_name,
        ot.type_category,
        COUNT(f.fire_id) AS fire_count,
        SUM(COALESCE(c.deaths_total, 0)) AS total_deaths,
        SUM(COALESCE(c.injured_total, 0)) AS total_injured,
        AVG(COALESCE(f.actual_damage_rub, f.estimated_damage_rub)) AS avg_damage_rub
    FROM object_types ot
    LEFT JOIN fires f ON ot.object_type_id = f.object_type_id
    LEFT JOIN casualties c ON f.fire_id = c.fire_id
    GROUP BY ot.type_name, ot.type_category
    ORDER BY total_deaths DESC, total_injured DESC, fire_count DESC
    LIMIT 10;
END //
DELIMITER ;

-- 3. Анализ времени реагирования по подразделениям
DELIMITER //
CREATE PROCEDURE sp_response_time_analysis()
BEGIN
    SELECT 
        fd.department_name,
        COUNT(rt.response_id) AS responses_count,
        AVG(rt.response_time_min) AS avg_response_time,
        MIN(rt.response_time_min) AS min_response_time,
        MAX(rt.response_time_min) AS max_response_time,
        AVG(rt.total_duration_min) AS avg_total_duration,
        SUM(CASE WHEN rt.response_time_min <= 10 THEN 1 ELSE 0 END) AS within_standard_count,
        ROUND(SUM(CASE WHEN rt.response_time_min <= 10 THEN 1 ELSE 0 END) * 100.0 / COUNT(rt.response_id), 2) AS within_standard_percent
    FROM fire_departments fd
    LEFT JOIN response_times rt ON fd.department_id = rt.primary_department_id
    GROUP BY fd.department_name
    ORDER BY avg_response_time;
END //
DELIMITER ;

-- 4. Сезонный анализ пожаров
DELIMITER //
CREATE PROCEDURE sp_seasonal_analysis(IN year_param INT)
BEGIN
    SELECT 
        CASE 
            WHEN MONTH(incident_date) IN (12, 1, 2) THEN 'Зима'
            WHEN MONTH(incident_date) IN (3, 4, 5) THEN 'Весна'
            WHEN MONTH(incident_date) IN (6, 7, 8) THEN 'Лето'
            WHEN MONTH(incident_date) IN (9, 10, 11) THEN 'Осень'
        END AS season,
        COUNT(*) AS fire_count,
        AVG(area_fire_m2) AS avg_fire_area,
        SUM(COALESCE(actual_damage_rub, estimated_damage_rub, 0)) AS total_damage,
        AVG(weather_temp_celsius) AS avg_temperature,
        AVG(weather_wind_speed_ms) AS avg_wind_speed
    FROM fires
    WHERE YEAR(incident_date) = year_param
    GROUP BY season
    ORDER BY FIELD(season, 'Зима', 'Весна', 'Лето', 'Осень');
END //
DELIMITER ;

-- 5. Отчет по экономическому ущербу
DELIMITER //
CREATE PROCEDURE sp_damage_report(IN date_from DATE, IN date_to DATE)
BEGIN
    SELECT 
        r.region_name,
        COUNT(f.fire_id) AS fire_count,
        SUM(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)) AS total_damage_rub,
        AVG(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)) AS avg_damage_per_fire,
        SUM(COALESCE(f.insurance_payout_rub, 0)) AS total_insurance_payout,
        SUM(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)) - 
        SUM(COALESCE(f.insurance_payout_rub, 0)) AS uncompensated_damage
    FROM fires f
    JOIN settlements s ON f.settlement_id = s.settlement_id
    JOIN regions r ON s.region_id = r.region_id
    WHERE f.incident_date BETWEEN date_from AND date_to
    GROUP BY r.region_name
    ORDER BY total_damage_rub DESC;
END //
DELIMITER ;

-- ====================================================================
-- ИНДЕКСЫ ДЛЯ ОПТИМИЗАЦИИ
-- ====================================================================

CREATE INDEX idx_fires_date_range ON fires(incident_date, status);
CREATE INDEX idx_fires_severity_date ON fires(severity_level, incident_date);
CREATE INDEX idx_casualties_deaths ON casualties(deaths_total, injured_total);
CREATE INDEX idx_response_times_performance ON response_times(response_time_min, arrival_time);

-- ====================================================================
-- ТРИГГЕРЫ ДЛЯ АВТОМАТИЗАЦИИ
-- ====================================================================

-- Автоматическое определение уровня серьезности пожара
DELIMITER //
CREATE TRIGGER trg_set_severity_level
BEFORE INSERT ON fires
FOR EACH ROW
BEGIN
    IF NEW.severity_level IS NULL THEN
        SET NEW.severity_level = CASE
            WHEN NEW.area_fire_m2 < 100 OR NEW.estimated_damage_rub < 500000 THEN 'малый'
            WHEN NEW.area_fire_m2 < 500 OR NEW.estimated_damage_rub < 5000000 THEN 'средний'
            WHEN NEW.area_fire_m2 < 2000 OR NEW.estimated_damage_rub < 50000000 THEN 'крупный'
            ELSE 'особо крупный'
        END;
    END IF;
END //
DELIMITER ;

-- Валидация временных меток в response_times
DELIMITER //
CREATE TRIGGER trg_validate_response_times
BEFORE INSERT ON response_times
FOR EACH ROW
BEGIN
    IF NEW.dispatch_time < NEW.call_received_time THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Время отправки не может быть раньше времени вызова';
    END IF;
    
    IF NEW.arrival_time < NEW.dispatch_time THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Время прибытия не может быть раньше времени отправки';
    END IF;
    
    IF NEW.extinguish_time IS NOT NULL AND NEW.extinguish_time < NEW.arrival_time THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Время тушения не может быть раньше времени прибытия';
    END IF;
END //
DELIMITER ;

-- ====================================================================
-- ФУНКЦИИ ДЛЯ РАСЧЕТОВ
-- ====================================================================

-- Расчет общего ущерба с учетом инфляции
DELIMITER //
CREATE FUNCTION fn_calculate_adjusted_damage(
    damage_amount DECIMAL(15,2),
    incident_year INT,
    base_year INT
) RETURNS DECIMAL(15,2)
DETERMINISTIC
BEGIN
    DECLARE inflation_rate DECIMAL(5,4);
    DECLARE years_diff INT;
    DECLARE adjusted_amount DECIMAL(15,2);
    
    SET inflation_rate = 0.05; -- 5% годовая инфляция (настраивается)
    SET years_diff = base_year - incident_year;
    SET adjusted_amount = damage_amount * POWER(1 + inflation_rate, years_diff);
    
    RETURN adjusted_amount;
END //
DELIMITER ;

-- Расчет коэффициента эффективности подразделения
DELIMITER //
CREATE FUNCTION fn_department_efficiency_score(
    department_id_param INT
) RETURNS DECIMAL(5,2)
READS SQL DATA
BEGIN
    DECLARE avg_response DECIMAL(10,2);
    DECLARE avg_duration DECIMAL(10,2);
    DECLARE efficiency_score DECIMAL(5,2);
    
    SELECT 
        AVG(response_time_min),
        AVG(total_duration_min)
    INTO avg_response, avg_duration
    FROM response_times
    WHERE primary_department_id = department_id_param;
    
    -- Чем меньше время, тем выше оценка (максимум 10)
    SET efficiency_score = GREATEST(0, 10 - (avg_response / 10) - (avg_duration / 60));
    
    RETURN ROUND(efficiency_score, 2);
END //
DELIMITER ;

-- ====================================================================
-- КОММЕНТАРИИ К ТАБЛИЦАМ
-- ====================================================================

ALTER TABLE fires COMMENT = 'Основная таблица учета пожаров';
ALTER TABLE response_times COMMENT = 'Таблица времени реагирования и тушения';
ALTER TABLE casualties COMMENT = 'Таблица пострадавших и жертв пожаров';
ALTER TABLE deployed_resources COMMENT = 'Таблица задействованных сил и средств';

-- ====================================================================
-- КОНЕЦ СКРИПТА
-- ====================================================================
