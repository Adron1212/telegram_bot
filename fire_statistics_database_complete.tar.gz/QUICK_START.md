# 🚀 БЫСТРЫЙ СТАРТ

## Шаг 1: Установка базы данных

### MySQL/MariaDB
```bash
mysql -u root -p < fire_statistics_database.sql
```

### PostgreSQL (требуется адаптация синтаксиса)
```bash
psql -U postgres -d fire_statistics_db < fire_statistics_database.sql
```

## Шаг 2: Настройка подключения

```sql
-- Создайте пользователя для работы с базой
CREATE USER 'fire_user'@'localhost' IDENTIFIED BY 'secure_password';
GRANT ALL PRIVILEGES ON fire_statistics_db.* TO 'fire_user'@'localhost';
FLUSH PRIVILEGES;
```

## Шаг 3: Заполнение справочников

```sql
USE fire_statistics_db;

-- 1. Добавьте ваши регионы
INSERT INTO regions (region_name, region_code, population, area_km2) 
VALUES ('Ваш регион', 'XX', 1000000, 50000);

-- 2. Добавьте населенные пункты
INSERT INTO settlements (region_id, settlement_name, settlement_type, population) 
VALUES (1, 'Город', 'город', 500000);

-- 3. Добавьте пожарные подразделения
INSERT INTO fire_departments (region_id, department_name, address, phone, staff_count, vehicle_count) 
VALUES (1, 'ПСЧ-1', 'ул. Пожарная, 1', '+7-XXX-XXX-XX-XX', 50, 10);
```

## Шаг 4: Регистрация первого пожара

```sql
-- Создаем запись о пожаре
INSERT INTO fires (
    incident_date, incident_time, detection_datetime,
    settlement_id, address, object_type_id, cause_id,
    severity_level, area_fire_m2, estimated_damage_rub, status
) VALUES (
    '2026-02-10', '14:30:00', '2026-02-10 14:30:00',
    1, 'ул. Ленина, д. 25', 1, 2,
    'средний', 45.5, 1500000, 'активный'
);

-- Получаем ID пожара
SET @fire_id = LAST_INSERT_ID();

-- Добавляем время реагирования
INSERT INTO response_times (
    fire_id, call_received_time, dispatch_time, arrival_time,
    primary_department_id
) VALUES (
    @fire_id,
    '2026-02-10 14:30:00',
    '2026-02-10 14:32:00',
    '2026-02-10 14:41:00',
    1
);

-- Добавляем информацию о пострадавших
INSERT INTO casualties (fire_id, deaths_total, injured_total, evacuated_total) 
VALUES (@fire_id, 0, 2, 15);

-- Регистрируем задействованные силы
INSERT INTO deployed_resources (
    fire_id, department_id, personnel_count, 
    vehicle_type_id, vehicle_count,
    arrival_time, water_used_liters
) VALUES (
    @fire_id, 1, 12, 1, 2,
    '2026-02-10 14:41:00', 8000
);
```

## Шаг 5: Просмотр статистики

```sql
-- Детальная информация о пожарах
SELECT * FROM v_fires_detailed 
WHERE incident_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY);

-- Статистика по регионам
SELECT * FROM v_region_statistics;

-- Эффективность подразделений
SELECT * FROM v_department_performance;

-- Статистика по причинам
SELECT * FROM v_cause_statistics;
```

## Шаг 6: Выполнение аналитических запросов

```sql
-- Динамика пожаров за 2026 год
CALL sp_monthly_fire_dynamics(2026);

-- Самые опасные типы объектов
CALL sp_most_dangerous_object_types();

-- Анализ времени реагирования
CALL sp_response_time_analysis();

-- Экономический ущерб за период
CALL sp_damage_report('2026-01-01', '2026-12-31');
```

## 📊 Структура файлов

```
fire-statistics-db/
├── fire_statistics_database.sql      # Основной скрипт создания БД
├── database_documentation.md         # Полная документация
├── analytical_queries.sql            # Коллекция запросов для анализа
└── database_structure_diagram.png    # Визуальная схема БД
```

## 🔧 Базовые операции

### Обновление статуса пожара
```sql
UPDATE fires SET status = 'потушен' WHERE fire_id = 1;
```

### Добавление времени локализации
```sql
UPDATE response_times 
SET localization_time = '2026-02-10 15:15:00',
    extinguish_time = '2026-02-10 16:30:00'
WHERE fire_id = 1;
```

### Обновление фактического ущерба
```sql
UPDATE fires SET actual_damage_rub = 2000000 WHERE fire_id = 1;
```

## 📈 Типовые отчеты

### Ежедневный отчет
```sql
SELECT 
    COUNT(*) AS пожаров_за_сутки,
    SUM(COALESCE(c.deaths_total, 0)) AS погибших,
    SUM(COALESCE(c.injured_total, 0)) AS пострадавших
FROM fires f
LEFT JOIN casualties c ON f.fire_id = c.fire_id
WHERE f.incident_date = CURDATE();
```

### Недельный отчет
```sql
SELECT * FROM v_fires_detailed 
WHERE incident_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
ORDER BY incident_date DESC;
```

### Месячный отчет
```sql
CALL sp_monthly_fire_dynamics(YEAR(CURDATE()));
```

## 🛠️ Обслуживание

### Резервное копирование
```bash
mysqldump -u root -p fire_statistics_db > backup_$(date +%Y%m%d).sql
```

### Восстановление из резервной копии
```bash
mysql -u root -p fire_statistics_db < backup_20260210.sql
```

### Оптимизация таблиц
```sql
OPTIMIZE TABLE fires, response_times, casualties, deployed_resources;
```

## 📞 Дополнительная информация

- **Полная документация**: см. файл `database_documentation.md`
- **Аналитические запросы**: см. файл `analytical_queries.sql`
- **Схема БД**: см. файл `database_structure_diagram.png`

## ⚠️ Важные замечания

1. **Безопасность**: Измените пароли пользователей БД
2. **Резервное копирование**: Настройте автоматическое резервное копирование
3. **Индексы**: Проверяйте использование индексов для оптимизации запросов
4. **Производительность**: При большом объеме данных (>100,000 записей) рассмотрите партиционирование таблиц

## 🎯 Следующие шаги

1. Заполните справочники вашими данными
2. Интегрируйте с существующими системами учета
3. Настройте автоматическую генерацию отчетов
4. Разработайте веб-интерфейс или мобильное приложение
5. Настройте визуализацию на картах (GIS-интеграция)

---

**Версия:** 1.0  
**Дата:** Февраль 2026  
**Поддержка:** Для государственных и муниципальных организаций
