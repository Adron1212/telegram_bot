-- ====================================================================
-- КОЛЛЕКЦИЯ АНАЛИТИЧЕСКИХ SQL ЗАПРОСОВ
-- Для базы данных учета статистики пожаров
-- ====================================================================

-- ====================================================================
-- 1. ОПЕРАТИВНЫЕ ЗАПРОСЫ (для ежедневной работы)
-- ====================================================================

-- 1.1. Активные пожары на текущий момент
SELECT 
    f.fire_id,
    f.incident_date,
    f.incident_time,
    s.settlement_name,
    f.address,
    ot.type_name AS тип_объекта,
    f.severity_level AS уровень_опасности,
    TIMESTAMPDIFF(MINUTE, f.detection_datetime, NOW()) AS минут_с_обнаружения,
    fd.department_name AS ответственное_подразделение,
    f.status
FROM fires f
JOIN settlements s ON f.settlement_id = s.settlement_id
JOIN object_types ot ON f.object_type_id = ot.object_type_id
LEFT JOIN response_times rt ON f.fire_id = rt.fire_id
LEFT JOIN fire_departments fd ON rt.primary_department_id = fd.department_id
WHERE f.status IN ('активный', 'локализован')
ORDER BY f.incident_date DESC, f.incident_time DESC;

-- 1.2. Пожары за последние 24 часа
SELECT 
    f.fire_id,
    f.detection_datetime,
    s.settlement_name,
    f.address,
    ot.type_name,
    fc.cause_name,
    f.severity_level,
    COALESCE(c.deaths_total, 0) AS погибших,
    COALESCE(c.injured_total, 0) AS пострадавших,
    rt.response_time_min AS время_реагирования_мин,
    f.status
FROM fires f
JOIN settlements s ON f.settlement_id = s.settlement_id
JOIN object_types ot ON f.object_type_id = ot.object_type_id
LEFT JOIN fire_causes fc ON f.cause_id = fc.cause_id
LEFT JOIN casualties c ON f.fire_id = c.fire_id
LEFT JOIN response_times rt ON f.fire_id = rt.fire_id
WHERE f.detection_datetime >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
ORDER BY f.detection_datetime DESC;

-- 1.3. Пожары, требующие внимания (превышено время реагирования)
SELECT 
    f.fire_id,
    f.detection_datetime,
    s.settlement_name,
    f.address,
    rt.response_time_min AS время_реагирования_мин,
    rt.response_time_min - 10 AS превышение_норматива_мин,
    fd.department_name
FROM fires f
JOIN settlements s ON f.settlement_id = s.settlement_id
JOIN response_times rt ON f.fire_id = rt.fire_id
JOIN fire_departments fd ON rt.primary_department_id = fd.department_id
WHERE rt.response_time_min > 10
  AND f.incident_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
ORDER BY rt.response_time_min DESC;

-- ====================================================================
-- 2. СТАТИСТИЧЕСКИЕ ЗАПРОСЫ
-- ====================================================================

-- 2.1. Сводная статистика за период (настраиваемый)
SELECT 
    COUNT(*) AS всего_пожаров,
    COUNT(DISTINCT s.settlement_id) AS населенных_пунктов_затронуто,
    
    -- По уровню серьезности
    SUM(CASE WHEN f.severity_level = 'малый' THEN 1 ELSE 0 END) AS малых,
    SUM(CASE WHEN f.severity_level = 'средний' THEN 1 ELSE 0 END) AS средних,
    SUM(CASE WHEN f.severity_level = 'крупный' THEN 1 ELSE 0 END) AS крупных,
    SUM(CASE WHEN f.severity_level = 'особо крупный' THEN 1 ELSE 0 END) AS особо_крупных,
    
    -- Площадь
    ROUND(SUM(f.area_fire_m2), 2) AS общая_площадь_м2,
    ROUND(AVG(f.area_fire_m2), 2) AS средняя_площадь_м2,
    ROUND(MAX(f.area_fire_m2), 2) AS максимальная_площадь_м2,
    
    -- Ущерб
    ROUND(SUM(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)), 2) AS общий_ущерб_руб,
    ROUND(AVG(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)), 2) AS средний_ущерб_руб,
    ROUND(SUM(COALESCE(f.insurance_payout_rub, 0)), 2) AS страховые_выплаты_руб,
    
    -- Пострадавшие
    SUM(COALESCE(c.deaths_total, 0)) AS погибших_всего,
    SUM(COALESCE(c.deaths_children, 0)) AS погибших_детей,
    SUM(COALESCE(c.injured_total, 0)) AS пострадавших_всего,
    SUM(COALESCE(c.injured_children, 0)) AS пострадавших_детей,
    SUM(COALESCE(c.evacuated_total, 0)) AS эвакуировано_всего,
    
    -- Время реагирования
    ROUND(AVG(rt.response_time_min), 1) AS среднее_время_реагирования_мин,
    ROUND(AVG(rt.total_duration_min), 1) AS средняя_длительность_работ_мин
    
FROM fires f
JOIN settlements s ON f.settlement_id = s.settlement_id
LEFT JOIN casualties c ON f.fire_id = c.fire_id
LEFT JOIN response_times rt ON f.fire_id = rt.fire_id
WHERE f.incident_date BETWEEN '2026-01-01' AND '2026-12-31';  -- Настраиваемый период

-- 2.2. Динамика по дням недели
SELECT 
    DAYNAME(f.incident_date) AS день_недели,
    DAYOFWEEK(f.incident_date) AS номер_дня,
    COUNT(*) AS количество_пожаров,
    ROUND(AVG(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)), 2) AS средний_ущерб,
    SUM(COALESCE(c.deaths_total, 0)) AS погибших,
    SUM(COALESCE(c.injured_total, 0)) AS пострадавших
FROM fires f
LEFT JOIN casualties c ON f.fire_id = c.fire_id
WHERE f.incident_date >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH)
GROUP BY DAYNAME(f.incident_date), DAYOFWEEK(f.incident_date)
ORDER BY номер_дня;

-- 2.3. Распределение по времени суток
SELECT 
    CASE 
        WHEN HOUR(f.incident_time) BETWEEN 0 AND 5 THEN '00:00-06:00 (Ночь)'
        WHEN HOUR(f.incident_time) BETWEEN 6 AND 11 THEN '06:00-12:00 (Утро)'
        WHEN HOUR(f.incident_time) BETWEEN 12 AND 17 THEN '12:00-18:00 (День)'
        ELSE '18:00-00:00 (Вечер)'
    END AS время_суток,
    COUNT(*) AS количество_пожаров,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM fires WHERE incident_date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)), 2) AS процент,
    SUM(COALESCE(c.deaths_total, 0)) AS погибших,
    SUM(COALESCE(c.injured_total, 0)) AS пострадавших
FROM fires f
LEFT JOIN casualties c ON f.fire_id = c.fire_id
WHERE f.incident_date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
GROUP BY время_суток
ORDER BY FIELD(время_суток, '00:00-06:00 (Ночь)', '06:00-12:00 (Утро)', '12:00-18:00 (День)', '18:00-00:00 (Вечер)');

-- 2.4. Анализ погодных условий
SELECT 
    CASE 
        WHEN f.weather_temp_celsius < -10 THEN 'Сильный мороз (< -10°C)'
        WHEN f.weather_temp_celsius < 0 THEN 'Мороз (-10°C до 0°C)'
        WHEN f.weather_temp_celsius < 15 THEN 'Холодно (0°C до 15°C)'
        WHEN f.weather_temp_celsius < 25 THEN 'Тепло (15°C до 25°C)'
        ELSE 'Жара (> 25°C)'
    END AS температура,
    COUNT(*) AS пожаров,
    ROUND(AVG(f.area_fire_m2), 2) AS средняя_площадь_м2,
    ROUND(AVG(rt.total_duration_min), 1) AS средняя_длительность_мин
FROM fires f
LEFT JOIN response_times rt ON f.fire_id = rt.fire_id
WHERE f.weather_temp_celsius IS NOT NULL
  AND f.incident_date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
GROUP BY температура
ORDER BY пожаров DESC;

-- 2.5. Влияние ветра на распространение огня
SELECT 
    CASE 
        WHEN f.weather_wind_speed_ms < 3 THEN 'Слабый ветер (< 3 м/с)'
        WHEN f.weather_wind_speed_ms < 7 THEN 'Умеренный ветер (3-7 м/с)'
        WHEN f.weather_wind_speed_ms < 12 THEN 'Сильный ветер (7-12 м/с)'
        ELSE 'Очень сильный ветер (> 12 м/с)'
    END AS сила_ветра,
    COUNT(*) AS пожаров,
    ROUND(AVG(f.area_fire_m2), 2) AS средняя_площадь_м2,
    ROUND(MAX(f.area_fire_m2), 2) AS максимальная_площадь_м2,
    ROUND(AVG(rt.total_duration_min), 1) AS средняя_длительность_тушения_мин
FROM fires f
LEFT JOIN response_times rt ON f.fire_id = rt.fire_id
WHERE f.weather_wind_speed_ms IS NOT NULL
GROUP BY сила_ветра
ORDER BY пожаров DESC;

-- ====================================================================
-- 3. АНАЛИЗ ПРИЧИН
-- ====================================================================

-- 3.1. ТОП-10 причин с детальной статистикой
SELECT 
    fc.cause_name AS причина,
    fc.cause_category AS категория,
    COUNT(f.fire_id) AS пожаров,
    ROUND(COUNT(f.fire_id) * 100.0 / (SELECT COUNT(*) FROM fires WHERE incident_date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)), 2) AS процент,
    
    -- Серьезность
    SUM(CASE WHEN f.severity_level IN ('крупный', 'особо крупный') THEN 1 ELSE 0 END) AS крупных_пожаров,
    
    -- Жертвы
    SUM(COALESCE(c.deaths_total, 0)) AS погибших,
    SUM(COALESCE(c.injured_total, 0)) AS пострадавших,
    
    -- Ущерб
    ROUND(SUM(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)) / 1000000, 2) AS ущерб_млн_руб,
    ROUND(AVG(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)) / 1000, 2) AS средний_ущерб_тыс_руб
    
FROM fire_causes fc
LEFT JOIN fires f ON fc.cause_id = f.cause_id AND f.incident_date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
LEFT JOIN casualties c ON f.fire_id = c.fire_id
GROUP BY fc.cause_name, fc.cause_category
HAVING пожаров > 0
ORDER BY пожаров DESC
LIMIT 10;

-- 3.2. Динамика причин по месяцам
SELECT 
    DATE_FORMAT(f.incident_date, '%Y-%m') AS месяц,
    fc.cause_name AS причина,
    COUNT(*) AS количество
FROM fires f
JOIN fire_causes fc ON f.cause_id = fc.cause_id
WHERE f.incident_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
GROUP BY месяц, fc.cause_name
ORDER BY месяц DESC, количество DESC;

-- 3.3. Причины с наибольшим количеством жертв
SELECT 
    fc.cause_name AS причина,
    COUNT(f.fire_id) AS пожаров,
    SUM(COALESCE(c.deaths_total, 0)) AS погибших,
    SUM(COALESCE(c.injured_total, 0)) AS пострадавших,
    ROUND(SUM(COALESCE(c.deaths_total, 0)) * 1.0 / NULLIF(COUNT(f.fire_id), 0), 2) AS погибших_на_пожар,
    ROUND(SUM(COALESCE(c.injured_total, 0)) * 1.0 / NULLIF(COUNT(f.fire_id), 0), 2) AS пострадавших_на_пожар
FROM fire_causes fc
LEFT JOIN fires f ON fc.cause_id = f.cause_id
LEFT JOIN casualties c ON f.fire_id = c.fire_id
WHERE f.incident_date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
GROUP BY fc.cause_name
HAVING погибших > 0 OR пострадавших > 0
ORDER BY погибших DESC, пострадавших DESC;

-- ====================================================================
-- 4. АНАЛИЗ ПО ТИПАМ ОБЪЕКТОВ
-- ====================================================================

-- 4.1. Детальная статистика по типам объектов
SELECT 
    ot.type_category AS категория,
    ot.type_name AS тип_объекта,
    COUNT(f.fire_id) AS пожаров,
    
    -- Средние показатели
    ROUND(AVG(f.area_fire_m2), 2) AS средняя_площадь_м2,
    ROUND(AVG(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)) / 1000, 2) AS средний_ущерб_тыс_руб,
    ROUND(AVG(rt.total_duration_min), 1) AS среднее_время_тушения_мин,
    
    -- Жертвы
    SUM(COALESCE(c.deaths_total, 0)) AS погибших,
    SUM(COALESCE(c.injured_total, 0)) AS пострадавших,
    SUM(COALESCE(c.evacuated_total, 0)) AS эвакуированных,
    
    -- Общий ущерб
    ROUND(SUM(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)) / 1000000, 2) AS общий_ущерб_млн_руб
    
FROM object_types ot
LEFT JOIN fires f ON ot.object_type_id = f.object_type_id 
    AND f.incident_date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
LEFT JOIN casualties c ON f.fire_id = c.fire_id
LEFT JOIN response_times rt ON f.fire_id = rt.fire_id
GROUP BY ot.type_category, ot.type_name
HAVING пожаров > 0
ORDER BY категория, пожаров DESC;

-- 4.2. Самые опасные типы объектов (по жертвам)
SELECT 
    ot.type_name AS тип_объекта,
    COUNT(f.fire_id) AS пожаров,
    SUM(COALESCE(c.deaths_total, 0)) AS погибших,
    SUM(COALESCE(c.injured_total, 0)) AS пострадавших,
    ROUND(SUM(COALESCE(c.deaths_total, 0)) * 100.0 / NULLIF(COUNT(f.fire_id), 0), 1) AS процент_смертности,
    SUM(COALESCE(c.deaths_children, 0)) AS погибших_детей,
    SUM(COALESCE(c.injured_children, 0)) AS пострадавших_детей
FROM object_types ot
LEFT JOIN fires f ON ot.object_type_id = f.object_type_id
LEFT JOIN casualties c ON f.fire_id = c.fire_id
WHERE f.incident_date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
GROUP BY ot.type_name
HAVING погибших > 0 OR пострадавших > 0
ORDER BY погибших DESC, пострадавших DESC;

-- ====================================================================
-- 5. ТЕРРИТОРИАЛЬНЫЙ АНАЛИЗ
-- ====================================================================

-- 5.1. Рейтинг регионов по пожарам
SELECT 
    r.region_name AS регион,
    COUNT(f.fire_id) AS пожаров,
    ROUND(COUNT(f.fire_id) * 100000.0 / r.population, 2) AS пожаров_на_100тыс_населения,
    
    -- Жертвы
    SUM(COALESCE(c.deaths_total, 0)) AS погибших,
    SUM(COALESCE(c.injured_total, 0)) AS пострадавших,
    
    -- Ущерб
    ROUND(SUM(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)) / 1000000, 2) AS ущерб_млн_руб,
    ROUND(SUM(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)) / r.population, 2) AS ущерб_на_душу_населения,
    
    -- Эффективность служб
    ROUND(AVG(rt.response_time_min), 1) AS среднее_время_реагирования_мин,
    SUM(CASE WHEN rt.response_time_min <= 10 THEN 1 ELSE 0 END) * 100.0 / COUNT(rt.response_id) AS процент_в_нормативе
    
FROM regions r
LEFT JOIN settlements s ON r.region_id = s.region_id
LEFT JOIN fires f ON s.settlement_id = f.settlement_id 
    AND f.incident_date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
LEFT JOIN casualties c ON f.fire_id = c.fire_id
LEFT JOIN response_times rt ON f.fire_id = rt.fire_id
GROUP BY r.region_name, r.population
HAVING пожаров > 0
ORDER BY пожаров_на_100тыс_населения DESC;

-- 5.2. Населенные пункты с наибольшим риском
SELECT 
    r.region_name AS регион,
    s.settlement_name AS населенный_пункт,
    s.settlement_type AS тип,
    COUNT(f.fire_id) AS пожаров_за_год,
    ROUND(COUNT(f.fire_id) * 100000.0 / NULLIF(s.population, 0), 2) AS пожаров_на_100тыс,
    
    SUM(CASE WHEN f.severity_level IN ('крупный', 'особо крупный') THEN 1 ELSE 0 END) AS крупных_пожаров,
    SUM(COALESCE(c.deaths_total, 0)) AS погибших,
    SUM(COALESCE(c.injured_total, 0)) AS пострадавших,
    
    ROUND(SUM(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)) / 1000000, 2) AS ущерб_млн_руб
    
FROM settlements s
JOIN regions r ON s.region_id = r.region_id
LEFT JOIN fires f ON s.settlement_id = f.settlement_id 
    AND f.incident_date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
LEFT JOIN casualties c ON f.fire_id = c.fire_id
GROUP BY r.region_name, s.settlement_name, s.settlement_type, s.population
HAVING пожаров_за_год >= 5  -- Только места с минимум 5 пожарами
ORDER BY пожаров_на_100тыс DESC
LIMIT 20;

-- 5.3. Карта концентрации пожаров (для геовизуализации)
SELECT 
    f.fire_id,
    f.incident_date,
    s.settlement_name,
    f.address,
    f.coordinates_lat AS широта,
    f.coordinates_lon AS долгота,
    f.severity_level,
    ot.type_name AS тип_объекта,
    COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0) AS ущерб_руб,
    COALESCE(c.deaths_total, 0) AS погибших,
    COALESCE(c.injured_total, 0) AS пострадавших
FROM fires f
JOIN settlements s ON f.settlement_id = s.settlement_id
JOIN object_types ot ON f.object_type_id = ot.object_type_id
LEFT JOIN casualties c ON f.fire_id = c.fire_id
WHERE f.coordinates_lat IS NOT NULL 
  AND f.coordinates_lon IS NOT NULL
  AND f.incident_date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
ORDER BY f.incident_date DESC;

-- ====================================================================
-- 6. АНАЛИЗ ЭФФЕКТИВНОСТИ ПОДРАЗДЕЛЕНИЙ
-- ====================================================================

-- 6.1. Комплексная оценка подразделений
SELECT 
    fd.department_name AS подразделение,
    r.region_name AS регион,
    
    -- Нагрузка
    COUNT(DISTINCT rt.fire_id) AS выездов,
    SUM(dr.personnel_count) AS всего_личного_состава,
    SUM(dr.vehicle_count) AS всего_техники,
    
    -- Время реагирования
    ROUND(AVG(rt.response_time_min), 1) AS среднее_время_реагирования_мин,
    MIN(rt.response_time_min) AS минимальное_мин,
    MAX(rt.response_time_min) AS максимальное_мин,
    SUM(CASE WHEN rt.response_time_min <= 10 THEN 1 ELSE 0 END) AS выездов_в_нормативе,
    ROUND(SUM(CASE WHEN rt.response_time_min <= 10 THEN 1 ELSE 0 END) * 100.0 / COUNT(rt.response_id), 1) AS процент_в_нормативе,
    
    -- Эффективность
    ROUND(AVG(rt.total_duration_min), 1) AS средняя_длительность_работ_мин,
    
    -- Безопасность
    SUM(COALESCE(c.rescuers_injured, 0)) AS пострадавших_спасателей,
    SUM(COALESCE(c.rescuers_deaths, 0)) AS погибших_спасателей,
    
    -- Результаты
    SUM(CASE WHEN f.status = 'потушен' THEN 1 ELSE 0 END) AS успешно_потушено
    
FROM fire_departments fd
JOIN regions r ON fd.region_id = r.region_id
LEFT JOIN response_times rt ON fd.department_id = rt.primary_department_id
LEFT JOIN deployed_resources dr ON fd.department_id = dr.department_id AND dr.fire_id = rt.fire_id
LEFT JOIN fires f ON rt.fire_id = f.fire_id
LEFT JOIN casualties c ON f.fire_id = c.fire_id
WHERE rt.call_received_time >= DATE_SUB(NOW(), INTERVAL 3 MONTH)
GROUP BY fd.department_name, r.region_name
ORDER BY выездов DESC;

-- 6.2. Сравнение подразделений по эффективности
SELECT 
    fd.department_name AS подразделение,
    COUNT(rt.fire_id) AS выездов,
    
    -- Баллы по критериям (чем выше, тем лучше)
    ROUND(10 - (AVG(rt.response_time_min) / 6), 2) AS балл_скорость_реагирования,
    ROUND(10 - (AVG(rt.total_duration_min) / 60), 2) AS балл_скорость_тушения,
    ROUND((SUM(CASE WHEN rt.response_time_min <= 10 THEN 1 ELSE 0 END) * 10.0 / COUNT(rt.response_id)), 2) AS балл_соблюдение_норматива,
    ROUND((SUM(CASE WHEN f.status = 'потушен' THEN 1 ELSE 0 END) * 10.0 / COUNT(f.fire_id)), 2) AS балл_результативность,
    
    -- Общий балл
    ROUND((
        (10 - (AVG(rt.response_time_min) / 6)) +
        (10 - (AVG(rt.total_duration_min) / 60)) +
        (SUM(CASE WHEN rt.response_time_min <= 10 THEN 1 ELSE 0 END) * 10.0 / COUNT(rt.response_id)) +
        (SUM(CASE WHEN f.status = 'потушен' THEN 1 ELSE 0 END) * 10.0 / COUNT(f.fire_id))
    ) / 4, 2) AS общий_балл
    
FROM fire_departments fd
LEFT JOIN response_times rt ON fd.department_id = rt.primary_department_id
LEFT JOIN fires f ON rt.fire_id = f.fire_id
WHERE rt.call_received_time >= DATE_SUB(NOW(), INTERVAL 3 MONTH)
GROUP BY fd.department_name
HAVING выездов >= 10  -- Минимум 10 выездов для статистики
ORDER BY общий_балл DESC;

-- 6.3. Использование ресурсов
SELECT 
    fd.department_name AS подразделение,
    vt.type_name AS тип_техники,
    
    COUNT(dr.deployment_id) AS выездов_техники,
    SUM(dr.vehicle_count) AS всего_единиц,
    ROUND(AVG(dr.work_duration_min), 1) AS среднее_время_работы_мин,
    
    SUM(dr.water_used_liters) AS воды_использовано_л,
    SUM(dr.foam_used_liters) AS пены_использовано_л,
    
    ROUND(AVG(dr.personnel_count), 1) AS среднее_личного_состава
    
FROM deployed_resources dr
JOIN fire_departments fd ON dr.department_id = fd.department_id
LEFT JOIN vehicle_types vt ON dr.vehicle_type_id = vt.vehicle_type_id
JOIN fires f ON dr.fire_id = f.fire_id
WHERE f.incident_date >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH)
GROUP BY fd.department_name, vt.type_name
ORDER BY подразделение, выездов_техники DESC;

-- ====================================================================
-- 7. ЭКОНОМИЧЕСКИЙ АНАЛИЗ
-- ====================================================================

-- 7.1. Анализ ущерба по категориям
SELECT 
    ot.type_category AS категория_объекта,
    COUNT(f.fire_id) AS пожаров,
    
    -- Ущерб
    ROUND(SUM(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)) / 1000000, 2) AS общий_ущерб_млн_руб,
    ROUND(AVG(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)) / 1000, 2) AS средний_ущерб_тыс_руб,
    ROUND(MAX(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)) / 1000000, 2) AS максимальный_ущерб_млн_руб,
    
    -- Страхование
    SUM(CASE WHEN f.insured = TRUE THEN 1 ELSE 0 END) AS застрахованных_объектов,
    ROUND(SUM(CASE WHEN f.insured = TRUE THEN 1 ELSE 0 END) * 100.0 / COUNT(f.fire_id), 1) AS процент_застрахованных,
    ROUND(SUM(COALESCE(f.insurance_payout_rub, 0)) / 1000000, 2) AS страховые_выплаты_млн_руб,
    
    -- Незастрахованный ущерб
    ROUND((SUM(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)) - 
           SUM(COALESCE(f.insurance_payout_rub, 0))) / 1000000, 2) AS незастрахованный_ущерб_млн_руб
    
FROM fires f
JOIN object_types ot ON f.object_type_id = ot.object_type_id
WHERE f.incident_date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
GROUP BY ot.type_category
ORDER BY общий_ущерб_млн_руб DESC;

-- 7.2. Динамика ущерба по месяцам
SELECT 
    DATE_FORMAT(f.incident_date, '%Y-%m') AS месяц,
    COUNT(f.fire_id) AS пожаров,
    ROUND(SUM(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)) / 1000000, 2) AS ущерб_млн_руб,
    ROUND(AVG(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)) / 1000, 2) AS средний_ущерб_тыс_руб,
    SUM(COALESCE(c.deaths_total, 0)) AS погибших,
    SUM(COALESCE(c.injured_total, 0)) AS пострадавших
FROM fires f
LEFT JOIN casualties c ON f.fire_id = c.fire_id
WHERE f.incident_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
GROUP BY месяц
ORDER BY месяц;

-- 7.3. ТОП-10 самых дорогих пожаров
SELECT 
    f.fire_id,
    f.incident_date,
    r.region_name AS регион,
    s.settlement_name AS населенный_пункт,
    f.address,
    ot.type_name AS тип_объекта,
    fc.cause_name AS причина,
    f.severity_level,
    ROUND(f.area_fire_m2, 2) AS площадь_м2,
    ROUND(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0) / 1000000, 2) AS ущерб_млн_руб,
    COALESCE(c.deaths_total, 0) AS погибших,
    COALESCE(c.injured_total, 0) AS пострадавших,
    f.insured AS застрахован,
    ROUND(COALESCE(f.insurance_payout_rub, 0) / 1000000, 2) AS страховая_выплата_млн_руб
FROM fires f
JOIN settlements s ON f.settlement_id = s.settlement_id
JOIN regions r ON s.region_id = r.region_id
JOIN object_types ot ON f.object_type_id = ot.object_type_id
LEFT JOIN fire_causes fc ON f.cause_id = fc.cause_id
LEFT JOIN casualties c ON f.fire_id = c.fire_id
WHERE f.incident_date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
ORDER BY ущерб_млн_руб DESC
LIMIT 10;

-- ====================================================================
-- 8. ПРОГНОЗНЫЕ И ТРЕНДОВЫЕ ЗАПРОСЫ
-- ====================================================================

-- 8.1. Сравнение с предыдущими годами
SELECT 
    YEAR(f.incident_date) AS год,
    COUNT(*) AS пожаров,
    SUM(CASE WHEN f.severity_level IN ('крупный', 'особо крупный') THEN 1 ELSE 0 END) AS крупных,
    SUM(COALESCE(c.deaths_total, 0)) AS погибших,
    SUM(COALESCE(c.injured_total, 0)) AS пострадавших,
    ROUND(SUM(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)) / 1000000, 2) AS ущерб_млн_руб,
    ROUND(AVG(rt.response_time_min), 1) AS среднее_время_реагирования_мин
FROM fires f
LEFT JOIN casualties c ON f.fire_id = c.fire_id
LEFT JOIN response_times rt ON f.fire_id = rt.fire_id
WHERE YEAR(f.incident_date) >= YEAR(CURDATE()) - 3
GROUP BY YEAR(f.incident_date)
ORDER BY год;

-- 8.2. Месячная динамика с трендом
SELECT 
    DATE_FORMAT(f.incident_date, '%Y-%m') AS месяц,
    COUNT(*) AS пожаров,
    AVG(COUNT(*)) OVER (ORDER BY DATE_FORMAT(f.incident_date, '%Y-%m') 
                        ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) AS скользящее_среднее_3мес,
    SUM(COALESCE(c.deaths_total, 0)) AS погибших,
    ROUND(SUM(COALESCE(f.actual_damage_rub, f.estimated_damage_rub, 0)) / 1000000, 2) AS ущерб_млн_руб
FROM fires f
LEFT JOIN casualties c ON f.fire_id = c.fire_id
WHERE f.incident_date >= DATE_SUB(CURDATE(), INTERVAL 24 MONTH)
GROUP BY месяц
ORDER BY месяц;

-- ====================================================================
-- КОНЕЦ КОЛЛЕКЦИИ ЗАПРОСОВ
-- ====================================================================
